package com.main.service;

import com.main.dto.UserDTO;
import java.sql.ResultSet;

public class UserCardService {

    public static void main(String[] args) {
        UserDTO userDTO = new UserDTO();
        userDTO.setCardNumber("123456799123");
        userDTO.setCardPin("1212");
        userDTO.setAnswer("cricket");
        userDTO.setQuestion("1");
        boolean validateCard = validateCard(userDTO);
        System.out.println("validateCard = " + validateCard);
    }

    public static UserDTO getUserById(String id) {
        boolean isValid = false;
        String sql = "SELECT * FROM `tbl_registration` WHERE id = " + id + " ";
        System.out.println("sql = " + sql);
        UserDTO userDTO = new UserDTO();
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                userDTO.setUsername(executeQuery.getString("txtUserName"));
                userDTO.setFirstName(executeQuery.getString("txtFullName"));
                userDTO.setCardNumber(executeQuery.getString("cardNumber"));
                userDTO.setEmaild(executeQuery.getString("txtEMail"));
            }
        } catch (Exception e) {
            System.out.println("e[validateCard] = " + e.getMessage());
        }
        return userDTO;
    }

    public static boolean validateCard(UserDTO dTO) {
        boolean isValid = false;
        String sql = "SELECT id FROM `tbl_registration` WHERE "
                + " `cardNumber` = '" + dTO.getCardNumber() + "' AND "
                + " `cardPin` = " + dTO.getCardPin() + " AND "
                + " `question` = " + dTO.getQuestion() + " AND "
                + " `answer` = '" + dTO.getAnswer() + "' AND "
                + " `otp` = '" + dTO.getOtp() + "' "
                + "  ";
        System.out.println("sql = " + sql);
        try {
            ResultSet executeQuery = MsAccessConnection.preStateMent(sql).executeQuery();
            while (executeQuery.next()) {
                isValid = true;
            }
        } catch (Exception e) {
            System.out.println("e[validateCard] = " + e.getMessage());
        }
        return isValid;
    }

    public static boolean blockCard(String userID) {
        String cardLogin = "UPDATE `tbl_registration` SET `isActive` = 'N' WHERE `id` = " + userID;
        System.out.println("cardLogin = " + cardLogin);
        try {
            return MsAccessConnection.preStateMent(cardLogin).execute();
        } catch (Exception e) {
            System.out.println("e[blockCard] = " + e.getMessage());
        }
        return false;
    }

}
