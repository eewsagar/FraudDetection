/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.service;

import java.sql.ResultSet;

public class UserService {

    public static void main(String[] args) {
        String string = new UserService().getEmailIdByUserId("20");
        System.out.println("string = " + string);
    }

    public String getEmailIdByUserId(String userId) {
        String userName = "";
        try {

            String login = "SELECT  txtEMail  FROM  `tbl_registration`  "
                    + " WHERE  `id` =  '" + userId + "' ";
            try {
                ResultSet executeQuery = MsAccessConnection.preStateMent(login).executeQuery();
                while (executeQuery.next()) {
                    userName = executeQuery.getString("txtEMail");
                }
            } catch (Exception e) {
                System.out.println("e = " + e.getMessage());
            }
        } catch (Exception e) {
        }
        return userName;
    }
}
