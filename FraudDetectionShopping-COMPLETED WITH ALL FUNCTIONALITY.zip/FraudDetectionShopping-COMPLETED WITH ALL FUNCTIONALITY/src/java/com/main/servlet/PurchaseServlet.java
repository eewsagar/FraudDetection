package com.main.servlet;

import com.main.dto.UserDTO;
import com.main.service.MsAccessConnection;
import com.main.service.UserCardService;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author PraviN
 */
@WebServlet(name = "PurchaseServlet", urlPatterns = {"/PurchaseServlet"})
public class PurchaseServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String cardNumber = request.getParameter("cardNumber");
            String amount = request.getParameter("amount");
            String productId = request.getParameter("productId");
            String userId = request.getParameter("userId");
            String price = request.getParameter("price");

            String cardPin = request.getParameter("cardPin");
            String question = request.getParameter("question");
            String answer = request.getParameter("answer");
            String otp = request.getParameter("otp");

            UserDTO userDTO = new UserDTO();
            userDTO.setCardNumber(cardNumber);
            userDTO.setCardPin(cardPin);
            userDTO.setQuestion(question);
            userDTO.setAnswer(answer);
            userDTO.setOtp(otp);

            if (UserCardService.validateCard(userDTO)) {
                String sql = "INSERT INTO `tbl_purchase` ("
                        + "`cardNumber`, "
                        + "`amount`, "
                        + "`productId`, "
                        + "`userId`, "
                        + "`price`, "
                        + "`isActive`"
                        + ") VALUES ("
                        + "'" + cardNumber + "', "
                        + "'" + amount + "', "
                        + "'" + productId + "', "
                        + "'" + userId + "', "
                        + "'" + price + "', "
                        + "'Y');";
                try {
                    MsAccessConnection.preStateMent(sql).execute();
                    response.sendRedirect("index.jsp?page=message");
                } catch (IOException e) {
                    response.sendRedirect("index.jsp?page=message&isValid=false");
                } catch (SQLException e) {
                    response.sendRedirect("index.jsp?page=message&isValid=false");
                }
            } else {
                UserCardService.blockCard(userId);
                response.sendRedirect("index.jsp?page=message&isValid=false");
            }

//            String avtStrAmt = "";
//            try {
//                String sqlAvg = "SELECT avg(`price`) as avg FROM `tbl_purchase` WHERE `userId` = " + userId;
//                ResultSet executeQuery = MsAccessConnection.preStateMent(sqlAvg).executeQuery();
//                while (executeQuery.next()) {
//                    avtStrAmt = executeQuery.getString("avg");
//                }
//            } catch (SQLException e) { //eat excepion
//            }
//            int purchaseAmt = 0;
//            int avgAmt = 0;
//            int capAmt = 150;
//            boolean isValid = false;
//            String isActive = "N";
//            try {
//                purchaseAmt = Integer.parseInt(price);
//                avgAmt = Integer.parseInt(avtStrAmt);
//                if (purchaseAmt <= (avgAmt + capAmt)) {
//                    isValid = true;
//                    isActive = "Y";
//                }
//            } catch (Exception e) {
//            }
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
