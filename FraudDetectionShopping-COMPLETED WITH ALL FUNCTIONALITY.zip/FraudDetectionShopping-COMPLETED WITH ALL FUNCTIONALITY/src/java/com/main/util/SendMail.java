/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.util;

import com.main.service.MsAccessConnection;
import com.main.service.Sendemail;
import com.main.service.UserService;

/**
 *
 * @author PraviN
 */
public class SendMail {

    public static void main(String[] args) {
        sendOTP("20");
    }
    
    public static void sendRegistrationMail(String userName, String password) {
        try {
            Sendemail.sucessRegistration(userName, ""
                    + "YOUR LOGIN DETAILS : - \n"
                    + "USERNAME :-  "
                    + "" + userName + "\n"
                    + "PASSWORD  :- "
                    + "" + password + "\n"
                    + ""
                    + "");
        } catch (Exception e) {
        }
    }

    public static void sendActivationMail(String userName) {
        try {
            Sendemail.sucessRegistration(userName, ""
                    + "YOUR CARD / LOGIN ACTIVATED: - \n"
                    + "");
        } catch (Exception e) {
        }
    }

    public static void sendOTP(String userId) {
        String emailId = new UserService().getEmailIdByUserId(userId);
        String pinNumber = new CardUtil().generateCardPin();
        System.out.println("pin otp:"+pinNumber);
        try {

            String updateOTP = "UPDATE  `tbl_registration` "
                    + " SET  `otp` =  '" + pinNumber + "' "
                    + " WHERE `id` = " + userId + ";";
            try {
                System.out.println("i m here in cardutil msaccess: "+updateOTP);
                MsAccessConnection.preStateMent(updateOTP).execute();
            } catch (Exception e) {
                System.out.println("e = " + e);
            }
            Sendemail.sucessRegistration(emailId, ""
                    + "YOUR PURCHASE OTP " + pinNumber
                    + "");
        } catch (Exception e) {
            System.out.println("e = " + e.getMessage());
        }
    }

}
