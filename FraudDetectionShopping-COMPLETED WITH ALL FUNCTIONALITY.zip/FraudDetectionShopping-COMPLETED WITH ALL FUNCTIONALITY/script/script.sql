DROP DATABASE IF EXISTS fraudDetectionShopping;
CREATE DATABASE  fraudDetectionShopping;
USE  fraudDetectionShopping;
 
CREATE TABLE IF NOT EXISTS `application` (
  `AppId` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Dob` varchar(50) NOT NULL,
  `UnitNo` varchar(50) NOT NULL,
  `StName` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `AppDate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`AppId`, `FirstName`, `LastName`, `Dob`, `UnitNo`, `StName`, `Phone`, `AppDate`) VALUES
('1', 'pravin', 'tumsare', '12//11/1989', '01252', '1515', '959595', '19/12/2013'),
('2', 'pravin', 'tumsare', '12/11/1989', '151', '1515', '9595793227', '19/12/2013'),
('3', 'pravin', 'tumsare', '12/11/1989', '123', '123', '123', '19/12/2013'),
('4', 'pravin', 'tumsare', '12/11/1989', '123', '123', '123', '19/12/2013'),
('5', 'sagar', 'warma', '15/5/1989', '123', '123', '123', '21/12/2013');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `AppId` varchar(20) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Verification` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`AppId`, `Status`, `Verification`) VALUES
('1', 'Checked', 'Accepted'),
('2', 'Checked', 'Accepted'),
('3', 'Checked', 'Accepted'),
('4', 'Checked', 'Rejected'),
('5', 'Checked', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entryDate` varchar(255) DEFAULT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` varchar(255) DEFAULT NULL,
  `isActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `entryDate`, `categoryName`, `categoryDescription`, `isActive`) VALUES
(6, 'Sun Mar 16 16:23:17 IST 2014', 'BOOK', 'THIS IS CATEGORY OF THE ALL BOOKS', 'Y'),
(7, 'Sun Mar 16 16:23:29 IST 2014', 'CLOTHING', 'CLOTHING CATEGORY', 'Y'),
(8, 'Sun Mar 16 16:23:47 IST 2014', 'ELECTRONICS', 'ELECTRONICS CATEGORY', 'Y'),
(9, 'Sun Mar 16 16:23:55 IST 2014', 'KITCHEN', 'CATEGORY', 'Y'),
(10, 'Sun Mar 16 16:24:11 IST 2014', 'TOYS & GAMES', 'TOYS & GAMES CATEGORY', 'Y'),
(16, 'Wed Mar 01 00:36:44 IST 2017', 'Mobile', 'Mobile is the day to day life part  of every individual.', 'Y'),
(12, 'Fri Mar 28 03:08:05 IST 2014', 'pavin', 'adds ad ads\r\n', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_interset`
--

CREATE TABLE IF NOT EXISTS `tbl_interset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pCategory` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=46 ;

--
-- Dumping data for table `tbl_interset`
--

INSERT INTO `tbl_interset` (`id`, `pCategory`) VALUES
(1, 'book'),
(2, 'book'),
(3, 'TURNING'),
(4, 'comics'),
(5, 'comic'),
(6, 'DENIM'),
(7, 'LOVE'),
(8, 'BLUE JEANS'),
(9, 'BLUE JEANS'),
(10, 'SARI'),
(11, 'NESTING EGGS'),
(12, 'NESTING'),
(13, 'MADRAT'),
(14, 'GAME'),
(15, 'FUNSKOOL '),
(16, 'Touchsmart '),
(17, 'Touchsmart'),
(18, 'Laptop'),
(19, 'Samsung '),
(20, 'Polychromic '),
(21, 'polychromic '),
(22, 'polychromic '),
(23, 'polychromic '),
(24, 'polychromic '),
(25, 'polychromic '),
(26, 'polychromic '),
(27, 'polychromic '),
(28, 'Denim '),
(29, 'Denim'),
(30, 'Denim      '),
(31, 'Denim'),
(32, 'Denim'),
(33, 'MECCANO'),
(34, 'MECCANO'),
(35, 'MECCANO'),
(36, 'APPLE '),
(37, 'APPLE'),
(38, 'LIFE IS WHAT YOU MAKE IT'),
(39, 'LIFE IS WHAT'),
(40, 'LIFE'),
(41, 'LIFE wi'),
(42, 'LIFE '),
(43, 'LIFE'),
(44, 'toy'),
(45, 'book');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txtFirstName` varchar(255) DEFAULT NULL,
  `txtLastName` varchar(255) DEFAULT NULL,
  `txtEMail` varchar(255) DEFAULT NULL,
  `txtUserName` varchar(255) DEFAULT NULL,
  `txtPassword` varchar(255) DEFAULT NULL,
  `txtType` varchar(255) DEFAULT NULL,
  `add` int(1) NOT NULL,
  `edit` int(1) NOT NULL,
  `delete` int(1) NOT NULL,
  `isActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `txtFirstName`, `txtLastName`, `txtEMail`, `txtUserName`, `txtPassword`, `txtType`, `add`, `edit`, `delete`, `isActive`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', 'admin', '1', 0, 0, 0, 'Y'),
(18, '12', '132', '123', '123', '123', '2', 1, 1, 0, 'T'),
(5, 'namita', 'tumsare', 'namitatumsare@gmail.com', 'namita', 'namita', '2', 0, 0, 0, 'T'),
(7, '123', '132', 'pravintumsare@gmail.com', '123', '123', '2', 1, 1, 0, 'T'),
(8, 'pravin tumsare', 'tumsare', 'pravintumsare@gmail.com', '123456', '123456', '2', 0, 1, 0, 'T'),
(9, 'pravin', 'pravin', 'pravin', 'pravintumsare', 'pravin', '3', 1, 1, 0, 'T'),
(10, '111', '111', '111', '111', '111', '3', 0, 1, 0, 'T'),
(12, '1', '1', '1', '1', '1', '3', 1, 1, 0, 'T'),
(21, '1231', '1231', '12332', '12313', '1231321', '2', 0, 0, 0, 'T'),
(22, '151', '5165165', '61561', '15615', '156165', '2', 0, 0, 0, 'T');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pCategory` varchar(255) DEFAULT NULL,
  `vImages` varchar(500) DEFAULT NULL,
  `entryDate` varchar(255) DEFAULT NULL,
  `pName` varchar(255) DEFAULT NULL,
  `pPrice` varchar(255) DEFAULT NULL,
  `description` text,
  `pType` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `vReview` varchar(10) DEFAULT NULL,
  `txtByAdder` varchar(20) NOT NULL,
  `isActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=90 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `pCategory`, `vImages`, `entryDate`, `pName`, `pPrice`, `description`, `pType`, `keywords`, `vReview`, `txtByAdder`, `isActive`) VALUES
(1, 'BOOK', '14', 'Wed Mar 19 11:35:43 PDT 2014', 'turning point', '145', 'Summary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\nSummary Of The Book	\r\nThis book, Turning Points: A Journey Through Challenges, takes up the story from when A.P.J Abdul Kalam became the President of India. It covers his acceptance of the post of the President of India, his term in office, his efforts to make his term meaningful, and the challenges he faced.\r\n', 'novel', 'turning point,novel', '4', '0', 'Y'),
(2, 'BOOK', '13', 'Wed Mar 19 11:49:26 PDT 2014', 'life is what you make it', '54', 'Life Is What You Make It is a fictional story about a strong female character whose life takes unexpected turns and how she uses her indomitable spirit to make the most of it.\r\n\r\nSummary Of The Book:\r\nLife Is What You Make It is a story about a young female protagonist whose life gets shaken by her destiny in a highly unexpected manner. Set across two Indian cities in 1989, the story begins when Ankita is shown to be reading letters that she exchanged with Vaibhav. And here onward, the reader is taken on a flashback story that relates the life of Ankita and how she ended up in a hospital.\r\n', 'novel', 'life,love story', '10', '0', 'Y'),
(3, 'TOYS & GAMES', '11', 'Wed Mar 19 11:56:18 PDT 2014', 'BESTWAY BABY STEPS ROLLER ', '325', '<b>Key Features</b>\r\n<br/>?	Encourages Baby to Crawl and <b>Take their First Steps</b>\r\n?<br/>	Inflatable Tube\r\n?	Multi-coloured Balls and Bells Inside the Roller\r\n?	Colourful Design\r\nThe Baby Steps Roller from Bestway acts as a great tool to develop early learning skills and and motor skills in your child.\r\nInflatable Tube\r\nThis Baby Step Roller can be blown or inflated with air or gas so that your little child can have fun playing with it.\r\nEncourages Baby To Crawl And Take Their First Steps\r\nExclusively designed, this Steps Roller is the best way to help your baby to crawl and take their first steps.\r\nColorful Design\r\nThe fun colors and trendy design are sure to impress your little one.\r\nMulti-colored Balls And Bells Inside The Roller\r\nFor added fun and excitement, there are multi-colored balls and bells stored inside the roller.\r\n', 'toys', 'baby toys,bestway baby roller', '2', '0', 'Y'),
(13, 'TOYS & GAMES', '20', 'Wed Mar 19 13:57:26 PDT 2014', 'MADRAT GAMES BHEEM TEAM BOARD GAME', '275', 'Key Features\r\n?	Related to the TV Cartoons\r\n?	4 Years +\r\n?	Aids Childrens Memory and Social Skills\r\nYour children will now understand Chhota Bheem and enjoy with his friends when they sit to play this amazing board game that is brought to you from the house of MadRat Games. \r\nAids Children?s Memory And Social Skills\r\nBuilding team play, this game brings your children closer to their friends as they sit to play this amazing and fun-filled game. Your child?s social skills get a boost and he also develops his interpersonal skills. This game also enhances your child?s recapitulation power and grasping abilities and this in turn aids his memory.\r\nRelated To The TV Cartoons\r\nChhota Bheem is set to rescue his friends from the evil Daku. This interesting and captivating board game is inspired by the TV cartoons. Playing this game will also make your children watch the series on a regular basis.\r\n', 'funskool game', 'bheem game,madrat games', NULL, '0', 'Y'),
(14, 'TOYS & GAMES', '21', 'Wed Mar 19 13:59:49 PDT 2014', 'Skillofun Capital Alphabet Tray with Picture', '310', 'Key Features\r\n?	Material: Medium Density Fibreboard\r\n?	There are Sixteen Objects - Four per Category\r\n?	Knobs to Lift The Letters\r\n?	Provides An Initial Introduction to Alphabets\r\n?	Sharpens Motor Skills\r\n?	Each Side has Four Cavities of Different Categories - Transport, Animals, Fruits and Shapes\r\n?	Identify Each Object and its Respective Cavity and Post it in the Correct Cavity. The Object Must Fall into thePostingBox\r\n?	This Wooden Toy Helps Beginners get a Solid Experience with Early Learning Concepts - Grip, Placement and Shape\r\nThe Capital Alphabet Tray with Picture from the house of Skillofun ensures unlimited fun and entertainment for your kids as they make their first attempt to learn alphabets.\r\nMade From Wood\r\nCrafted from wood, this Capital Alphabet Tray ensures long-lasting durability.\r\nKnobs To Lift The Letters\r\nA knob is fitted which can be used to lift the letters so that your child can see the hidden pictures underneath.\r\nProvides An Initial Introduction To Alphabets\r\nDesigned with attractive and fun images, this Skillofun Capital Alphabet Tray acts as a great tool to introduce your kid to the world of alphabets.\r\nSharpens Motor Skills\r\nBy playing with this educational toy, your child?s motor skills are sharpened.\r\nNon-Toxic\r\nMade of non-toxic paints, this Skillofun Capital Alphabet Tray with Picture is safe for kids to play with.\r\n', 'skillofun', 'alphabet tray', NULL, '0', 'Y'),
(5, 'TOYS & GAMES', '12', 'Wed Mar 19 13:13:32 PDT 2014', 'CHINESE CHECKERS BOARD GAME', '199', 'Key Features\r\n?	Improve Logical Reasoning and Honing their Strategising Skills\r\nFunskool Chinese Checkers Board game is your perfect companion for spending quality time with kids. Chinese Checkers is a popular board game that can be played by two, three, four or six players, individually or in teams. Although known as Chinese checkers, this game of strategy was first devised in Germany. The main objective of this game is to move all your coloured pieces into the home of your opponent. This addictive game comes in handy when you go for outings and picnics. Encourage your little tot, boys and girls alike, older than seven years to play this board game to improve their logical reasoning and honing their strategising skills. This game set can also suffice as a good birthday gift for your young relatives or friends of your little angel.\r\nObjective	\r\nThe legendary game of Chinese Checkers allows two to six people to indulge in a battle of wits. Strategically place the pieces in the corner opposite their starting position, in the pitted hexagram by single moves or jump over other pieces in this fun-filled bundle of excitement.\r\n', 'board game', 'board games,chinese  games', '2', '0', 'Y'),
(6, 'TOYS & GAMES', '13', 'Wed Mar 19 13:24:33 PDT 2014', 'GAME OF LIFE BOARD GAME ', '500', 'Key Features	\r\n?	Unique 3 Dimensional Game\r\n?	6 Players\r\nThe Game of Life Board Game by Funskool is highly engaging and the perfect game for the whole family which brings happiness and fun to your family playtime.\r\nUnique 3 Dimensional Game\r\nEasy to carry as it weighs 1430 g and features an unique three dimension with a width of 20.47 inch, height of 11.81 inch and depth of 1.97 inch, and is convenient to play on a flat surface.\r\n6 Players\r\nPerfect for children aged above nine years, this board game is more enjoyable and interesting when played by six people as you experience the twists and turns of real life through fun.\r\n', 'board game', 'board games,life game', NULL, '0', 'Y'),
(7, 'TOYS & GAMES', '14', 'Wed Mar 19 13:27:14 PDT 2014', 'HUNGRY HIPPOS GAME BOARD GAME ', '549', 'Key Features\r\n?	Can be Played by 2 or More Players\r\n?	Improves Hand-eye Coordination\r\nThe hippos are very hungry and they are ready to gobble up all the marbles. The Hippo who eats the most marbles wins the game. This fun game is suitable for both girls and boys over the age of 3. Play Sweetie Potamus, Veggie Potamus, Picky Potamus or Bottomless Potamus and collect as many marbles as you can to race to victory. The Funskool Hungry Hippos Board Game is suitable for both boys and girls over the age of 3. The Hungry Hippo Board Game can be played by 2 to 4 players and it helps improve hand eye coordination. The game also inculcates the competitive spirit and is fun to play multiple times. Race to find out whose hippo is the hungriest.\r\nObjective	\r\nThe Hungry Hippos is a fast and furious action game, which can be played by four players. The hippos are hungry and waiting to munch on marbles. The game is simple and interesting, the hippo who swallows most of the marbles wins the game. So make sure that your hippo gobbles most of the marbles and makes you the ultimate winner of the game\r\n', 'board game', 'hungry hippos,board games', NULL, '0', 'Y'),
(8, 'TOYS & GAMES', '15', 'Wed Mar 19 13:29:00 PDT 2014', 'NESTING EGGS', '5151', ' Key Features\r\n?	Non Toxic Plastic\r\n?	5 Take Apart Colorful Eggs in Different Sizes that Nest\r\n?	Matching Colors, Shapes and Sizes\r\n?	Develops the Childs Observation Skills\r\n?	Develops Hand-eye Coordination\r\nColourful and bright, these nesting eggs from Funskool help your children to develop in many ways and help them in the long run.\r\n5 Take Apart Colorful Eggs In Different Sizes That Nest\r\nThe five colourful nesting eggs can be pulled apart and joined again.\r\nMatching Colors, Shapes And Sizes\r\nThese toy eggs help your children to understand the shapes and sizes and also help them to match the colours and join the eggs.\r\nDevelops Hand-Eye Coordination\r\nYour children will enhance their hand-eye coordination when they see the colours and join the pieces of the nesting eggs accordingly.\r\nDevelops The Childs Observation Skills\r\nYour children will elevate their observation skills when they play with this toy as they learn how to differentiate between different colours and shapes while playing with the set.\r\n', 'funschool game', 'funschool games,eggs game', '2', '0', 'Y'),
(9, 'TOYS & GAMES', '16', 'Wed Mar 19 13:31:29 PDT 2014', 'FUNSKOOL SLIDES AND LADDERS BOARD GAME', '224', 'Cute, colourful and attractively packaged, this fun loving game by Funskool is all set to capture your little one?s attention. Race to the top with other players to find out which one of these characters win. Will it be Dora the explorer, Boots the mischievous monkey, Backpack and Maps or Diego, her charming little cousin? Suitable for children above the ages of four, this marvellous Slides and Ladders Board Game is just the refreshing break your child needs after a tiring day at school.The Funskool Slides and Ladders Board game encourages your child to compete and bring out his/her ability in some fast thinking.\r\nFun, yet challenging, this board game brings out your child?s competitive best. Score some points by racing to the top with the ladders, and find out who descends downwards through the slides. Wait and watch, as to which lucky player races the others to the top of the fiesta.  This exciting game kit comprises of four character pawns, one Spinner, one Spinner Board and a detailed Instruction Sheet. So, go ahead, and give your child a pleasant surprise of fun and wit.\r\nObjective\r\nThis game of Slides and Ladders is another take on the popular game of snakes and ladders but a lot less scary in order to be playable by younger kids. Here Dora, Boots, Diego, Backpack and Map are racing to reach the fiesta. Roll the dice and if you coin falls on a square with a ladder you can go up to the top of it. If you land on one with a slide, you have to slide down to where it ends. Make your way up the board again and whoever reaches the fiesta first wins the game.\r\n', 'board game', 'board game,funskool game', '2', '0', 'Y'),
(10, 'TOYS & GAMES', '17', 'Wed Mar 19 13:33:50 PDT 2014', 'FUNSKOOL TWISTER BOARD GAME', '359', 'Key Features\r\n?	Includes Team Spirit\r\n?	Can be Played Indoors or Outdoors\r\n?	Full of Action\r\n?	Real Body Bender\r\nLet your kids twist themselves into hilarious knots and tangle their bodies to win this fun-filled game.\r\n\r\nReal body bender\r\nThis Twister Board Game lives up to its name and lets the players bend and twist themselves innovatively in order to win the game.\r\n\r\nFull of action\r\nDevised for non-stop action, the game progresses into complicated postures as the contestants try to outwit each other in a laugh-a-minute session of fun and excitement.\r\n\r\nInculcates Team Spirit\r\nPlayed as a team competition, the game engenders team spirit and social interaction amongst the players and improves the inventive improvisations of the mind.\r\n\r\nCan be played indoors or outdoors\r\nBeing a board game with a perimeter of a body length, this game can be played indoors or outdoors with the same ease of setting up of the board.\r\n', 'board game', 'board game,funskool game', NULL, '0', 'Y'),
(11, 'TOYS & GAMES', '18', 'Wed Mar 19 13:35:16 PDT 2014', 'FUNSKOOL WALK N DRIVE TRUCK', '449', 'Key Features\r\n?	Front Wheels Can By Turned By Rotating The Steering\r\n?	Adjustable Steering Shaft\r\n?	Easy to Assemble\r\n?	Steering Wheel for Child to Hold and Walk\r\nGive your children, a fun-filled pull-along toy by Funskool that grows with them at each stage.\r\nSteering wheel for child to hold and walk\r\nThe steering wheel helps your little one gain stability while walking and also provides a fun handle to hold onto and move around.\r\nAdjustable steering shaft\r\nThe steering shaft is adjustable and can be lengthened to suit the height of a fast-growing child.\r\nEasy to assemble	\r\nThe Funskool Walk N Drive Truck arrives in a handy box and the adjustable steering shaft of the toy can be easily attached or detached for quick use.\r\nFront wheels can by turned by rotating the steering\r\nWatch your children boost their motor skills by maneuvering the steering wheel during the walking motion and experiencing the dynamics of forward and lateral movement.\r\n', 'roller game', 'funschool games,roller', NULL, '0', 'Y'),
(16, 'BOOK', '12', 'Wed Mar 19 14:03:38 PDT 2014', 'The Oath of the Vayuputras: Shiva Trilogy 3', '192', 'India?s own super hero is finally here. Shiva has risen yet again to destroy the evildoers. The last of the Shiva Trilogy, this book promises to keep the readers gripped while the great warrior discovers who his true enemies are and gives it his all to destroy them.', 'novel', 'vayuputras', NULL, '0', 'Y'),
(17, 'BOOK', '15', 'Wed Mar 19 14:04:40 PDT 2014', 'what young india wants', '106', 'What Young India Wants is a compilation of Chetan Bhagats essays and speeches on India, its youth, its society, culture and politics. It also contains his ideas of what is needed to take the country forward, and what he thinks the youth of the country want.\r\nSummary Of The Book\r\nAfter writing some successful novels, Chetan Bhagat penned his first nonfiction work. This book contains all his hopes and dreams, and his fears and anxieties about India. What Young India Wants is divided into three sections, the first titled Our Society. In this, he looks at various aspects of Indian society and also does a comparison between Indian and American societies. He also goes into the issues of religion, terrorism, and caste differences.\r\n', 'novel', 'young india,novel', '16', '0', 'Y'),
(18, 'ELECTRONICS', '18', 'Wed Mar 19 14:09:47 PDT 2014', 'Dell Inspiron 15R 5537 Laptop ', '45892', ' didnt bought it from flipkart but Dell Showroom. On flipkart its for around 48000&#8377; and i bought it for 51000&#8377; but with 6GB of RAM and 1TB of HDD and a accessory kit from dell+a laptop bag.\r\nThe performance is amazing. And mind you the dell customer service is just awesome.\r\nI had 1 dead pixel on my laptop which i didnt noticed for 2 weeks but dell replaced it(in 4 days) even if it didnt fit into their dell pixel policy which describes that your screen must have at least 6 dead pixel to be get replaced.\r\nSo, Just check yours for dead pixel as soon as you got one and get it replaced if theres some because once you know that there is a black dot on your screen (besides its very tiny) thats all you see.\r\n', 'dell laptop', 'dell inspiron,laptop', NULL, '0', 'Y'),
(19, 'ELECTRONICS', '19', 'Wed Mar 19 14:11:40 PDT 2014', 'HP Envy Touchsmart 15-j109TX Laptop', '82686', 'The specs are good ... This machine is a real powerhouse , The 1080p screen rocks but due to the gloss finish of the screen it catches fingerprints easily...\r\nGraphic card is some what mid-end\r\nits the GT series with a DDR3 Bus rather than the new GDDR5...\r\nGraphics performance is decent but not top notch ...\r\nIf youre into gaming go for an Alienware or an Asus\r\n\r\nBuild Quality is good except that the keyboard has a little flex near the arrow keys and the back has a flex near the HBP logo... \r\n\r\nCooling is very good though the fan is real noisy but it will do a great job at keeping the heat away from the main area thanks to HP coolsense..\r\n', 'laptop', 'HP laptop,laptop', NULL, '0', 'Y'),
(20, 'KITCHEN', '20', 'Wed Mar 19 14:14:32 PDT 2014', 'MORPHY RICHARDS SM3007 G SANDWICH MAKER ', '1404', 'Key Features\r\n?	2 Slice Capacity\r\n?	Non-stick Grill Plate\r\n?	Grilling Function\r\n?	700 - 750 W Power Consumption\r\n?	Non-Skid Feet\r\n?	Preheating Feature\r\nThe Morphy Richards sandwich maker helps you make 2 sandwiches at a time and saves a lot of your time. TheMorphy Richards sandwich maker has grill plates with which you can get perfectly toasted sandwiches.\r\nThe plates close together which seals the sandwich completely and enclose the fillings. You can fill your sandwiches with ingredients like mushroom, paneer and cheese which make it crisp outside and soft inside. The non-stick coated plates in this sandwich maker makes the cleaning process simple and quick. The Morphy Richards SM3007 G consumes 750 W of power.\r\nFunctions\r\nThe SM3007 G is a specially crafted appliance which is a space maker by design which helps you make snacks easily and quickly. The Morphy Richards SM3007 G has toasting and grilling functions which gives you crisp and brown sandwiches. The preheating function helps you to preheat the appliance for a minute and place the bread slices to toast. This feature allows you to get the toasting done in a lesser time. The Morphy Richards SM3007 G has ready-to-cook and power on neon lights, which alert you regarding when to place the bread slices for toasting.\r\nSafety and Convenience\r\nThe Morphy Richards appliance is easy to clean and you can remove the crumbs manually with the help of a damp cloth. The compact upright storage in this appliance helps you store the sandwich maker vertically which saves a lot of space in your kitchen. The Morphy Richards SM3007 G features an anti-skid feet which keeps your sandwich maker safely in place. This sandwich maker is easy to clean which makes your work simple. The handle of this sandwich maker is comfortable to handle and you can carry it around anywhere you want.\r\n', 'sandwich maker', 'sandwich maker,morphy sandwich maker', NULL, '0', 'Y'),
(21, 'KITCHEN', '19', 'Wed Mar 19 23:39:35 PDT 2014', 'MILAGROW REDHAWK ROBOTIC FLOOR CLEANER ', '21990', 'Key Features\r\n?	Robotic Charging\r\n?	Robotic Scheduling\r\n?	Robotic Obstacle Detection\r\n?	Robotic Stair Detection\r\n?	Automatic Dirt Detection\r\n?	1L Bag-free Vacuum Cleaning\r\n?	Wet Cleaning\r\nMilagrow Humantech is a company that is focusing on providing state-of-the-art intelligent robots that can offer round the clock assistance which will help replace domestic help. These robots will be able to perform a variety of functions that will make life easier, safer and economical. The Milagrow Redhawk Vacuum Cleaner is one such robot thatperforms multiple tasks to ensure your home is clean by the time you get back from work.\r\nThe Milagrow Redhawk Vacuum Cleaner is classified as a robotic vacuum cleaner that can deal with both dry and wet surfaces. The Redhawk is a bag-less model that has a 1 litre dust bin to store the dirt it collects. The average power consumption for this robot is about 45 to 60 W. The suction power ranges from 10 to 15 W depending on the intensity of cleaning required. This battery operated Redhawk uses 6 different modes to clean effectively with minimal noise.\r\nBody\r\nThe Milagrow Redhawk Vacuum Cleaner has a circular shape with flat ends on both the top and bottom. There are four operational buttons located around the digital screen that shows the current settings on which the Redhawk is performing. The dust bin, which collects the dirt, is located at the back just above the exhaust vent.\r\nThe Redhawk has a base clearance of 2.3 cm which allows it to travel across a range of surfaces and clean without stalling. This Power Vac has a 14.4 V Li rechargeable battery with a storage capacity of 2000 mAh. The Infrared sensor is positioned at the front just above the digital screen.\r\nPerformance Features\r\nThe Milagrow Redhawk Vacuum Cleaner takes about 3 to 4 hours to fully charge its batteries before it goes about cleaning the house. This Power Vac can perform an hour of non-stop cleaning on a full charge. The maximum airflow is 100 dm3 per minute which can remove tough dirt and dust easily.\r\nThe Milagrow Redhawk Vacuum Cleaners settings can be programed with the infrared remote control. The remote control has a range of 7 m which allows you to feed instructions to the Redhawk Vacuum Cleaner. The wheels of this Power Vac have a suspension system that allows the Redhawk to easily move from the ground to a carpet or rug. The suspension system also makes sure that the suction head is at the right height for optimal use.\r\nConvenience Features\r\nThe Milagrow RedHawk Robotic Vacuum Cleaner comes with a variety of features that make your home safe and clean. The RedHawk will start cleaning the house at the pre-scheduled time, once its done cleaning or is low (less than 15%) on battery power, it will return by itself to the docking station to recharge. The Redhawk follows the infrared signal emitted by the docking station and docks itself to the charger.\r\nThis robot automatically detects obstacles. When RedHawk knocks into something, its bumper retracts, activatingmechanical object sensors that realize it has encountered an obstacle, it then performs the sequential actions of backing up, rotating and moving forward until it finds a clear path.\r\nThis Power Vac can also detect the edges of stairs and beds to avoid falling off. It uses a cliff sensor which constantly sends out infrared signals, if these infrared signals do not bounce back to the Power Vac, it instantly stops and chooses a different cleaning path.\r\nThis Robotic Vacuum Cleaner can also kill germs, viruses and bacteria using its unique UV bulb. The UV bulb that is found underneath the RedHawk kills the micro-organisms by penetrating them and disrupting their genetic material. The Robotic 3 Way Cleaning process also ensures that pet hair & skin flakes are picked up, thereby making the ground safe for toddlers and children.\r\nThe Milagrow RedHawk has the ability to vary its cleaning intensity based on the amount of dirt, the Automatic Dirt Detection software lets the Power Vac know that it has to increase its suction power when it identifies high dirt areas. This detection ability follows the same mining-detection algorithms as used by many militaries worldwide.\r\nThe RedHawk employs 3 main spot cleaning modes to ensure exhaustive cleaning. The spot wall-to-wall cleaningthat is suitable for hard dirt, makes sure that the entire room is cleaned in a methodical manner along the walls. In thespot spiral mode, the Power Vac cleans in concentric circles which is extremely suitable for cleaning tough spots thoroughly. In the Zig Zag mode, the robot cleans dirty spots with Auto Intelligent Optimal cleaning.\r\nAnother interesting functionality of this product is the Infrared Space Isolation. Invisible barriers can be set up using the virtual walls available with the Power Vac to mark off areas. The Virtual Wall sends out infrared signals that the robot picks up with the receiver on its bumper, it then turns around and heads the other way.\r\n', 'Floor cleaner', 'Cleaner,Floor cleaner', NULL, '0', 'Y'),
(22, 'KITCHEN', '12', 'Wed Mar 19 23:44:55 PDT 2014', 'EUREKA FORBES EASY CLEAN PLUS HAND-HELD VACUUM CLEANER ', '2234', 'Key Features\r\n?	0.5 L Dust Capacity\r\n?	Blower Feature\r\n?	800 W Motor Power\r\nThe Eureka Forbes Easy Clean Vacuum Cleaner is a powerful handheld appliance that can handle a variety of cleaning tasks with ease. The Easy Clean Vacuum Cleaners compact design is bag-less and it collects dirt in the permanent dust bowl.\r\nThis Easy Clean Vacuum Cleaner from Eureka Forbes has a power requirement of 230 V and a maximum air flow of 14 litres/ second. The efficient motor can generate a suction and blower power of 800 W. The total suction pressure comes up to 1600 mm of water column with which even small coins can be sucked up.\r\nBody\r\nDesigned to be a handheld appliance, the Eureka Forbes Easy Clean Vacuum Cleaner is compact and lightweight. The suction opening is located at the front of the body and the blower opening is at the back. A flexible hose can be attached to either opening to activate the desired function.\r\nThe on/off switch is placed on the handle for easy access with the thumb. The dimensions of the Easy Clean Vacuum Cleaner are 280 x 140 x 180 mm and it weighs 1.8 kg. It has a long power cord and can be connected to extension tubes to avoid having to bend down while cleaning the floor.\r\nPerformance and Convenience Features\r\nThe handle is placed on top of the vacuum cleaner and has small hoops to fix a shoulder belt. The shoulder belt allows the user to carry the vacuum cleaner around without strain while in use. The Eureka Forbes Easy Clean Vacuum Cleaner is small enough to be stored in cupboards without occupying much space.\r\n', 'vacuum cleaner', 'cleaner,vacuum cleaner', '4', '0', 'Y'),
(23, 'KITCHEN', '16', 'Wed Mar 19 23:48:42 PDT 2014', 'JAIPAN JUMBO ROTI MAKER', '1122', 'KEY FEATURES \r\n?	1000 W Power Consumption\r\n?	Roti Maker\r\n?	Indicator Light\r\n?	Red Neon Light\r\n?	Stainless Steel Cover Plate\r\n\r\n	\r\n', 'Roti maker', 'roti maker,jaipan maker', NULL, '0', 'Y'),
(24, 'KITCHEN', '22', 'Wed Mar 19 23:53:35 PDT 2014', 'PHILIPS HD4816 POP UP TOASTER (METAL AND BLACK) ', '1194', 'Key Features\r\n?	Pop Up Toaster\r\n?	2 Slices\r\n?	Variable Browning\r\n?	800 W Power Consumption\r\nThe Philips 2 slice Pop up toaster with large bread slots in a compact metal design, has a sleek stainless steel body which retains heat and is a classic design. The Philips toaster consumes 800 watts of electricity. The space under the toaster allows air to flow in easily and cools down the toaster.\r\nFunctions\r\nThis Philips toaster has a feature of adjustable browning control where the heat levels can be adjusted to your preference and get your toasts the way you want it. You can stop the toasting process and pop up the bread any time by moving up the toasting lever manually. When the toast is ready, it pops up and the toaster switches off automatically. This compact designed toaster saves place in your counter top. The High lift feature in this HD4816 pop up toaster lifts up the small sized slices.\r\nSafety and Convenience\r\nIf a slice of bread gets stuck inside the toaster, unplug the appliance and let it cool down before you try to remove the bread. Do not use a knife or a sharp tool, as these may cause damage to the heating elements. To remove crumbs from the appliance, open the panel in the bottom of the appliance with a screwdriver.\r\n', 'Toaster', 'Philips toaster,toaster', NULL, '0', 'Y'),
(25, 'KITCHEN', '23', 'Wed Mar 19 23:58:27 PDT 2014', 'PHILIPS HD 7450 COFFEE MAKER ', '1690', 'The Philips HD7450 is a compact coffee machine with a sleek, ergonomic body that is designed to occupy minimal space. The coffee maker features a clean and simple interface and makes for an ideal appliance for those on the lookout for an uncomplicated coffee maker. The 0.6 liter water tank capacity of the Philips HD7450 translates to 6 cups of coffee.\r\nThe Philips HD7450 features a high funnel type filter that allows for even distribution of the coffee powder. This ensures optimal contact between the powder and water, thereby lending a full-bodied flavor and aroma to your coffee. The thermostat controlled hotplate in the Philips coffee machine can keep the decoction warm for extended periods. This is a useful feature for late afternoon lethargy where you desperately crave for a coffee, but too lazy to actually go brew a fresh cup.\r\nThe Drip stop feature in the Philips coffee maker is a useful inclusion; this allows you to interrupt the brewing process any time you like. Just pull out the Glass carafe and the machine will pause the brewing till you replace it in the initial position. It is however recommended that you do not interrupt the process midway as the coffee acquires full flavor only at the end of the brewing cycle.\r\nThe Philips 7450 comes with several useful features that add to your convenience. All detachable parts of the Philips HD7450 Coffee Maker are dishwasher-safe. The Cord Control inclusion saves you from the hassle of dealing with tangled up wires. The coffee machine comes with a translucent water tank which allows you to keep a constant check on the water level.\r\nAnother highlight of the Philips HD7450 is the relatively short brew time of 8 minutes. It is a highly desired feature in a coffee maker as longer brew time tends to add a slight bitterness to your coffee. Filter-fine ground coffee powder works best with this Philips coffee machine as it allows the water to evenly coat the granules. Consistency is another huge deal-clincher for coffee makers, and this is where the Philips HD7450 truly excels. The coffee maker is crafted to give you that perfectly brewed caffeine ecstasy, every single time.\r\n', 'coffee maker', 'philips coffee maker,coffee maker,maker', NULL, '0', 'Y'),
(26, 'KITCHEN', '13', 'Thu Mar 20 00:15:41 PDT 2014', 'Godrej Krystal Water Purifier', '2500', 'Tried boiling water? Then, tried a water purifier? Fed up of hefty gas and electricity bills but still not sure if your water is pure and safe for consumption. Godrej offers you Krystal Water Purifier, a high in quality and low in cost water purifier with a filtration efficiency of 99.99%. This easy to install purifier offers you the finest purification without the use of any chemicals. What is even better is that it retains the essential minerals in the water without using electricity for the purification process. All you need to do is connect your Krystal water purifier directly to the tap and enjoy clean and safe drinking water whenever.', 'Water purifier', 'purifier,water purifier', NULL, '0', 'Y'),
(27, 'KITCHEN', '14', 'Thu Mar 20 05:54:10 PDT 2014', 'Goodway Food Steamer', '1599', 'Key Features\r\n\r\n?	Capacity - 10 L\r\n?	Water Tank Capacity - 2 L\r\n?	High Temperature Resistance\r\n?	Energy Saving & Safe\r\n?	With Waste Water Tray\r\n', 'Steamer', 'food steamer,steamer', NULL, '0', 'Y'),
(28, 'KITCHEN', '27', 'Thu Mar 20 06:02:53 PDT 2014', 'Virtue Mixer Grinder ', '3999', 'Overview - Virtue Mixer Grinder - VMG 125 (2 Jar)\r\nIn todays modern world, mixer grinders are of utmost importance. This not only makes cooking a less time consuming process but also helps you handle the tiresome task like grinding easily. Virtue brings to you this excellent mixer grinder that comes with two jars. This comes with 450 watts powerful motor. This is equipped with high quality stainless steel blades that ensure a long life, flow breaker jars and circuit breaker. The base jar is crafted from high quality fibre glass which is non-corrosive and weather proof. This will surely act as a time saver in todays busy world.\r\n', 'Mixer', 'mixer,grinder', NULL, '0', 'Y'),
(29, 'KITCHEN', '24', 'Thu Mar 20 06:10:06 PDT 2014', 'Prestige Mixer Grinder ', '3599', 'Overview - Prestige Mixer Grinder ? Popular\r\nMost of us use special masalas, which are ground to perfection to get that aromatic and mouth watering taste that most Indian recipes possess. So a good mixer grinder is a must need in every kitchen. This mixer grinder from Prestige comes with three jars and can be used for dry grinding, wet grinding and chutney grinding. The 3 speed control, sturdy handles, water drain motor facility and other such unique features makes this grinder the perfect choice for your kitchen. Order this mixer grinder from Prestige today.\r\n', 'Mixer', 'prestige mixer,mixer,grinder', NULL, '0', 'Y'),
(30, 'CLOTHING', '11', 'Thu Mar 20 06:48:12 PDT 2014', 'Denim BLVD', '1600', 'InFest jeans I have ever worn, they look great, fit great, and last forever. The have a really fine smooth feeling denim that is more comfortable than most other jeans in this list, Im surprised that these arent high up on this list', 'jeans', ' denim,blue jeans', '2', '0', 'Y'),
(31, 'CLOTHING', '12', 'Thu Mar 20 06:51:06 PDT 2014', 'Silk Sari', '2000', 'A silk sari is a female garment in the Indian subcontinent. A sari is a strip of unstitched cloth, ranging from four to nine meters in length that is draped over the body in various styles. There are various traditional styles of saree: Sambalpuri Saree from East, Kanchipuram from South, Paithani from West and Banarasi from North among others. The most common style is for the sari to be wrapped around the waist, with one end then draped over the shoulder baring the midriff. The sari is usually worn over a petticoat. Blouse may be "backless" or of a halter neck style. These are usually more dressy with a lot of embellishments such as mirrors or embroidery and may be worn on special occasions. Women in the armed forces, when wearing a sari uniform, don a half-sleeve shirt tucked in at the waist. Teenage girls wear half-sarees, a three piece set consisting of a langa, a choli and a stole wrapped over it like a saree. Women usually wear full sarees.\r\nSaris are usually known with different names in different places. In Kerala, white saris with golden border, are known as kavanis and are worn on special occasions. A simple white sari, worn as a daily wear, is called a mundu. Saris are called pudavai in Tamil Nadu. In Karnataka, saris are called kupsas.\r\n', 'sari', 'silk sari,sari', '2', '0', 'Y'),
(32, 'CLOTHING', '13', 'Thu Mar 20 06:53:51 PDT 2014', 'Baluchari Sari', '3500', 'Baluchar Sari (Bengali:&#2476;&#2494;&#2482;&#2497;&#2458;&#2480;&#2496; &#2488;&#2494;&#2480;&#2495;) is a type of sari, a garment worn by women across India and Bangladesh. This particular type of sari originated in Bengal and is known for depictions of mythological scenes on the pallu of the sari. It is mainly produced in Murshidabad and producing one sari takes approximately one week or more. The Baluchari Sari has been granted the status of Geographical indication in India', 'sari', 'sari,baluchari sari', '2', '0', 'Y'),
(36, 'CLOTHING', '14', 'Thu Mar 20 06:57:40 PDT 2014', 'Banarasi saris', '5000', 'Banarasi saris are saris made in Varanasi, a city which is also called "Benares." These saris are historically considered to be among the finest saris in India and are known for their gold and silver brocade or zari, fine silk and opulent embroidery, and being highly sought after. These saris are made of finely woven silk and are decorated with intricate design, and because of these engravings, these saris are relatively heavy. Their special characteristics are Mughal inspired designs such as intricate intertwining floral and foliate motifs, kalga and bel, a string of upright leaves called jhallar at the outer, edge of border is a characteristic of these sarees. Other distinctive features are heavy gold work, compact weaving, figures with small details, metallic visual effects, pallus, jal (a net like pattern), and mina work.[1] These saris are an inevitable part of any Indian brides trousseau.[2][3]\r\nDepending upon the intricacy of designs and patterns, a sari can take anywhere from 15 days to a one month and sometimes up to six months to complete. Banarasi saris are mostly worn by Indian women on important occasions such as when attending a wedding and are expected to be complemented by the womans best jewellery\r\n', 'sari', 'banarasi sari,sari', NULL, '0', 'Y'),
(37, 'CLOTHING', '15', 'Thu Mar 20 06:59:01 PDT 2014', 'Bandhani', '1500', 'Bandhani is a type of tie-dye practiced mainly in the states of Rajasthan and Gujarat, India. The term bandhani is derived from the Sanskrit word banda ("to tie").\r\nBandhani is also known as Bandhej or Tie Dye or Bandhni or Bandana, etc. as per the regional pronunciation\r\n', 'sari', 'sari,bandhani', NULL, '0', 'Y'),
(38, 'CLOTHING', '16', 'Thu Mar 20 07:00:48 PDT 2014', 'Ilkal saree', '2000', 'Ilkal saree (Kannada:) is a traditional form of saree which is a common feminine wear in India. Ilkal saree takes its name from the town of Ilkal in the Bagalkot district of Karnataka state, India. Ilkal sarees are woven using cotton warp on the body and art silk warp for border and art silk warp for pallav portion of the saree. In some cases instead of art silk, pure silk is also used. Ilkal saree has been accorded Geographical Indication (GI) tag.[1] Its GI tag number is', 'saree', 'iikal saree,saree,sari', NULL, '0', 'Y'),
(39, 'CLOTHING', '17', 'Thu Mar 20 07:03:15 PDT 2014', 'Lehenga Style Saree', '10000', 'Lehenga style Saree is a new trend of Saree introduced in India. This is an aesthetic blend of the traditional Saree and a Lehenga choli. Lehenga style saree is normally 4.5 meters to 5.5 meters long. Here unlike a sari one doesnt have to form pleats but simply tuck and drape.\r\nAs that of a traditional saree, the lehenga style saree is worn over a petticoat (in skirt, pavadai in the south, and shaya in eastern India), along with a designer blouse called as the choli, which is the upper garment. The style[1] of choli mostly resembles that of the choli of a conventional Lehenga or Ghagra choli. Sometimes conventional blouses are also matched with lehenga style saree. The choli is mostly as that of halter neck style, deep neck or ?backless? style. As that of the saree, these cholis are also embellished with Kundan, beads, mirrors etc.\r\n', 'sari', 'lehenga saree,sari', NULL, '0', 'Y'),
(40, 'CLOTHING', '19', 'Thu Mar 20 07:04:17 PDT 2014', 'chiffon sari', '3000', 'The increased interaction with the British saw most women from royal families come out of purdah in the 1900s. This necessitated a change of dress. Maharani Indira Devi of Cooch Behar popularised the chiffon sari. She was widowed early in life and followed the convention of abandoning her richly woven Baroda shalus in favour of the traditional unadorned white. Characteristically, she transformed her ?mourning? clothes into high fashion. She had saris woven in France to her personal specifications, in white chiffon, and introduced the silk chiffon sari to the royal fashion repertoire. The chiffon sari did what years of fashion interaction had not done in India. It homogenised fashion across this land. Its softness, lightness and beautiful, elegant, caressing drape was ideally suited to the Indian climate', 'sari', 'sari,chiffon saree', '2', '0', 'Y'),
(41, 'CLOTHING', '22', 'Thu Mar 20 07:07:43 PDT 2014', 'Gota (embroidery)', '20000', 'Gota work is a type of Indian embroidery that originated in Rajasthan, India.[1][2][3] Gota embroidery uses the applique technique. Small pieces of zari ribbon are applied onto the fabric with the edges sewn down to create elaborate patterns. Gota embroidery is used extensively in South Asian wedding and formal clothes.', 'embroidery', 'saree,sari,gota', '2', '0', 'Y'),
(42, 'CLOTHING', '23', 'Thu Mar 20 07:08:57 PDT 2014', 'Ghagra choli', '35000', 'Gagra choli or Ghagra choli, which is also known as Lehenga choli, is the traditional clothing of women in Rajasthan[1][2] Gujarat,[3] Madhya Pradesh, Uttar Pradesh, Bihar, Sindh, Haryana, Himachal Pradesh, Uttarakhand, Punjab, Jammu & Hindi speaking Terai region of Nepal. It is a combination outfit of a Lehenga, tight Choli and a Dupatta.', 'sari', 'ghagra,sari', NULL, '0', 'Y'),
(43, 'CLOTHING', '24', 'Thu Mar 20 07:16:12 PDT 2014', 'Langa - Voni/Dhavani', '7500', 'This is a type of South Indian dress mainly worn in Andhra Pradesh and Tamil Nadu also in some parts of Kerala and Karnataka. This dress is a 3- piece apparel where Langa or Lehanga is the cone shaped long flowing skirt that covers the body from the waist, reaching the feet. In some cases, it might be as long as knees or just lower than the knees too. The second part is the blouse, or a jacket, that covers the upper part of the womans body. There are many varieties in a blouse like the one that has long sleeves, short sleeves, sleeveless etc. The length of the blouse is usually short- from lower neck to a few inches above the belly button/ navel.', 'langa', 'langa,sari', NULL, '0', 'Y'),
(44, 'CLOTHING', '25', 'Thu Mar 20 07:20:45 PDT 2014', 'Calvin Klein ', '1200', 'No other jeans got the quality and comfort better dan CK... Simply the best in busines... CK rules MAN!\r\nBecause many times I have bought a different kind of jeans, even dieseal and danim, levis and others but calvin klein is the best\r\n', 'jeans', 'jeans,calvin jeans', NULL, '0', 'Y'),
(45, 'CLOTHING', '26', 'Thu Mar 20 07:27:05 PDT 2014', 'Beige Art Silk Jacquard Readymade Patiala Kameez', '4500', 'Beige art silk jacquard readymade Kameez designed with zari and patch border work. Available with red art silk patiala and red brasso supernet dupatta comes along with this. Cotton fabric is used as lining of the kameez. (Slight variation in color and patch border work is possible.)', 'salwar', 'patiyala,salwar', NULL, '0', 'Y'),
(46, 'CLOTHING', '29', 'Thu Mar 20 07:29:22 PDT 2014', 'Beige Pure Satin, Net and Velvet Readymade Anarkali Churidar Kameez', '6100', 'Beige pure satin, net and velvet readymade anarkali kameez designed with resham, zari, stone and patch border work. Beige poly lycra churidar and beige net dupatta is available with this. Poly cotton fabric is used as lining of the kameez. (Slight variation in color and patch border is possible', 'salwar', 'salwar,chudidar', NULL, '0', 'Y'),
(47, 'CLOTHING', '30', 'Thu Mar 20 07:31:53 PDT 2014', 'Dark Pink Satin Readymade Churidar Kameez', '3100', 'Dark pink satin patch bordered readymade kameez with contrasting white cotton lycra churidar and net dupatta is available with this. (Slight variation in color is possible.)', 'salwar', 'chudidar,salwar,pink salwar', '2', '0', 'Y'),
(48, 'ELECTRONICS', '1', 'Thu Mar 20 07:45:28 PDT 2014', 'Apple iPhone 5S ', '50490', 'Key Features \r\nUp to 56x Faster GPU than the Original iPhone \r\nUltra-fast Wireless \r\nUp to 40x Faster CPU than the Original iPhone \r\n8 MP iSight Camera with 15% Large Images Sensor and Aperture of f/2.2 \r\nTouch ID: New Fingerprint Identity Sensor \r\n1.2 MP FaceTime HD Camera \r\nA7-chip High Performance 64-bit Architecture and M7 Motion Co-processor \r\niOS 7 New Features such as Smarter Multitasking; AirDrop and Control Centre \r\nApple Apps: iPhoto; iMovie; Keynote; Pages and Numbers \r\nA smartphone that is created to surpass the boundaries of technology, the iPhone 5S from Apple becomes an indispensible part of your life. A fine blend of powerful hardware with software designed to help the hardware reach its true potential, 5S is all set to change the way smartphones work.\r\n', 'cell phones', 'mobile,iphone,apple', '5', '0', 'Y'),
(49, 'ELECTRONICS', '2', 'Thu Mar 20 07:51:04 PDT 2014', 'Apple iPhone 5S ', '63430', 'Key Features \r\nA7-chip High Performance 64-bit Architecture and M7 Motion Co-processor \r\nUp to 40x Faster CPU than the Original iPhone \r\n1.2 MP FaceTime HD Camera \r\niOS 7 New Features such as Smarter Multitasking; AirDrop and Control Centre \r\nUltra-fast Wireless \r\nUp to 56x Faster GPU than the Original iPhone \r\nTouch ID: New Fingerprint Identity Sensor \r\n8 MP iSight Camera with 15% Large Images Sensor and Aperture of f/2.2 \r\nApple Apps: iPhoto; iMovie; Keynote; Pages and Numbers \r\nA smartphone that is created to surpass the boundaries of technology, the iPhone 5S from Apple becomes an indispensible part of your life. A fine blend of powerful hardware with software designed to help the hardware reach its true potential, 5S is all set to change the way smartphones work.\r\n', 'cell phones', 'mobile,iphone,apple', '3', '0', 'Y'),
(50, 'ELECTRONICS', '3', 'Thu Mar 20 07:52:53 PDT 2014', 'Google Nexus 7 2012 Tablet ', '20000', 'Key Features \r\n1.2 MP Front Facing Camera \r\n7-inch HD Display with 216 ppi \r\nWi-Fi Enabled \r\nAndroid v4.2 (Jelly Bean) OS \r\nNVIDIA Tegra 3 Quad Core Processor \r\nNFC (Android Beam) \r\n32 GB Internal Storage \r\nBeing one of the most sought after devices, this Nexus 7 Tablet combines technological expertise with precision and quality to deliver high-end performance and appearance.\r\n', 'cell phones', 'mobile,google nexus,tablet', NULL, '0', 'Y'),
(51, 'ELECTRONICS', '4', 'Thu Mar 20 07:54:27 PDT 2014', 'Samsung Galaxy Grand 2', '20630', 'Key Features of Samsung Galaxy Grand 2 (Black) \r\n8 MP Primary Camera \r\nAndroid v4.3 (Jelly Bean) OS \r\n1.9 MP HD Secondary Camera \r\n1.2 GHz Qualcomm Snapdragon Quad Core Processor \r\n5.25-inch TFT Touchscreen \r\nWi-Fi Enabled \r\nExpandable Storage Capacity of 64 GB \r\nDual SIM (GSM+ GSM) \r\n', 'cell phones', 'cell phone,mobile,samsung grand', NULL, '0', 'Y'),
(52, 'ELECTRONICS', '5', 'Thu Mar 20 07:56:03 PDT 2014', 'Samsung Galaxy Note 3 N9000 ', '49000', 'Key Features \r\nAndroid v4.3 (Jelly Bean) OS \r\nAir Gesture and Air View \r\nFull HD (1080p) Recording and Playback Support \r\nDual Camera: Dual Shot / Dual Recording / Dual Video Call \r\nS Pen Optimized Features: Air Command; Action Memo; Scrapbook; S Finder; Pen Window; Multi Window; Direct Pen Input \r\nSamsung Smart Scroll and Samsung Smart Pause \r\n2 MP Secondary Camera with Smart Stabilization and BSI Sensor \r\n13 MP Primary Camera with Auto Focus and BSI Sensor \r\nNFC Support \r\n5.7-inch Full HD Super AMOLED (1920 x 1080) Display \r\nOcta Core Processor (1.9 GHz Quad + 1.3 GHz Quad) and 3 GB RAM \r\nTaking the mundane into the realms of the outstanding, Samsung presents the Galaxy Note 3, a revolution in technology set in the palm of the hand. Beauty meets utility in this device that brings big changes to the small workings of your life\r\n', 'cell phones', 'samsung note,mobile,galaxy note 3', NULL, '0', 'Y');
INSERT INTO `tbl_product` (`id`, `pCategory`, `vImages`, `entryDate`, `pName`, `pPrice`, `description`, `pType`, `keywords`, `vReview`, `txtByAdder`, `isActive`) VALUES
(53, 'ELECTRONICS', '6', 'Thu Mar 20 07:57:43 PDT 2014', 'Samsung Galaxy S4 I9500', '30999', 'Key Features \r\nSmart Pause \r\nSmart Scroll \r\nAir View or Air Gesture \r\nGroup Play: Music Sharing \r\nOptical Reading \r\nChatON: Dual Video Call \r\nDual Shot \r\nSlimmer Yet Stronger \r\nRecording \r\nS Translater \r\nSamsung WatchON \r\nA flagship mobile that is designed to revolutionize the way smartphones are used in everyday life, the Samsung Galaxy S4 is not simply smart, it is technology that changes lives. The S4, touted to be a life companion, operates on the Android v4.2.2 (Jelly Bean) operating system and employs a first-of-its-kind, super powerful Octa Core processor, comprising of 1.6 Ghz Quad and 1.2 Ghz Quad processors, backed by 2 GB RAM and boasts of PowerVR SGX graphics for performance, speed and functionality which are literally off the charts\r\n', 'cell phones', 'samsung,galaxy s4,mobile', NULL, '0', 'Y'),
(54, 'ELECTRONICS', '7', 'Thu Mar 20 07:59:16 PDT 2014', 'Samsung Galaxy S Duos 2', '9990', 'Key Features of Samsung Galaxy S Duos 2 S7582 (Pure White) \r\nAndroid v4.2 (Jelly Bean) OS \r\n5 MP Primary Camera \r\n0.3 MP Secondary Camera \r\nDual SIM (GSM + GSM) \r\nWi-Fi Enabled \r\n4-inch TFT Capactive Touchscreen \r\nExpandable Storage Capacity of 64 GB \r\n1.2 GHz Dual Core Application Processor \r\n', 'cell phones', 'samsung galaxy,mobile', NULL, '0', 'Y'),
(55, 'KITCHEN', '1', 'Thu Mar 20 08:24:41 PDT 2014', 'Dekor World Polychromic Border Table Placemat', '499', 'IN THE BOX\r\nSales Package	Table Placemat\r\nNumber of Contents in Sales Package	Pack of 6\r\nGENERAL\r\nBrand	Dekor World\r\nColor	Maroon\r\nCollection	Polychromic Border\r\nMaterial	Polyster\r\nShape	Rectangle\r\nPattern	Stripes\r\nDesign Code	28\r\nStyle Code	DWPM-028\r\n', 'mat', 'table placement,table mat,mat', NULL, '0', 'Y'),
(56, 'KITCHEN', '2', 'Thu Mar 20 08:27:32 PDT 2014', 'Swayam Grillz Kitchen Linen Set', '795', 'SPECIFICATIONS OF SWAYAM GRILLZ KITCHEN LINEN SET (PACK OF 8)\r\nIN THE BOX\r\nSales Package	1 Apron, 1 Pot Holder, 2 Oven Gloves, 4 Napkins\r\nNumber of Contents in Sales Package	Pack of 8\r\nGENERAL\r\nBrand	Swayam\r\nColor	White, Brown, Beige\r\nCollection	Grillz\r\nMaterial	Cotton\r\nDesign Code	2522\r\nStyle Code	KS082522\r\nADDITIONAL FEATURES\r\nFabric Care	Machine Washable, Do Not Soak, Cold Wash, Dry in Shade\r\nOther Features	Gross Packed Dimension - 9.5 (W) x 14 (L) x 1 (D) inch, Thread Count - 200, Gross Packed Weight - 600 g\r\nDIMENSIONS\r\nOther Dimensions	Napkin Size - 17 (W) x 22 (L) inch, Apron Size - 36 (L) x 22 (W) inch, Pot Holder Size - 9 (L) x 9 (W) inch, Over Gloves Size - 12 (L) x 8 (W) inch\r\n', 'kitchen set', 'swayam grill,kitchen set', NULL, '0', 'Y'),
(57, 'KITCHEN', '3', 'Thu Mar 20 08:31:20 PDT 2014', 'Black & Decker SB3120 Hand Blender', '4575', 'Key Features\r\n?	Pulse Operation\r\n?	Detachable Shaft\r\n?	300 W Power Consumption\r\n?	Wall Mounting Bracket\r\n?	Stainless Steel Blade\r\n?	Hand Blender\r\n?	0.45 L Caliberated Beaker\r\nWith Black and Decker hand blender you have a versatile, effortless and indispensable kitchen helper at your service. If you thought a hand blender is only good for making milk shakes, baby food and other quick jobs, you will be surprised how much else it will do to help you get some really great ideas on your table. The Black and Decker hand blender is the ideal tool to enable you to create every dish you love with easy. Features: 300 Watts power, Pulse operation, 450ml Calibrated beaker, Stainless steel blades, Chopper bowl with stainless steel blades (SB3120), Detachable shaft, Wall mounting bracket. Package Contains: 1 x Black and Decker Hand Blender SB3120.\r\n', 'Mixer', 'blender,mixer', NULL, '0', 'Y'),
(58, 'KITCHEN', '4', 'Thu Mar 20 08:37:14 PDT 2014', 'PHILIPS HD9220/20 2.2 L AIR FRYER ', '12990', 'Key Features	\r\n?	Dishwasher-safe Parts\r\n?	Adjustable Temperature Control\r\n?	Integrated Air Filter\r\n?	Rapid Air Technology\r\n?	Timer\r\n?	The Food Separator can be bought from Philips Service Center for Rs. 485/-\r\nCooking has become easy, especially when you want to keep a watch on the calories you are consuming with the Philips Air Fryer. This air fryer will make it easy for you to cook with the use of minimal oil. Cook your favourite dishes with second thoughts about the amount of oil you are going to consume.\r\nRapid Air Technology for healthier frying\r\nPrepare your favourite dishes by using the rapid air technology of this air fryer. The technology of this fryer helps you bake, grill, fry and roast without much of an effort. Letting the snacks be a surprise for your kids is the minimal smell this air fryer gives out when something is being cooked.\r\n\r\nAdjustable time and temperature control\r\nThe Philips Air Fryer allows you to modulate the time and temperature to cook whatever you want to perfection. You can pre-set the timer of this appliance up to 30 minutes and the temperature up to 200 degrees. Relish crunchy fries, chicken and meat by setting the right temperature and time.\r\nWith the Airfryer you can fry, grill, roast and even bake\r\nThis air fryer is no ordinary kitchen appliance, you can not only grill and roast but also bake in it. An answer to all your cooking and baking problems, this air fryer will come in handy whenever you need to prepare a quick meal.\r\nRecipe booklet full of inspiring recipes\r\nIf you are a foodie, then the recipe booklet that comes with this air fryer is sure to impress you. With a variety of low-fat recipes, this booklet will also show you how to bake, grill and roast food in the air fryer with utmost convenience and ease.\r\nIs easy to clean and creates less smell than normal fryers\r\nThe air fryer keeps your kitchen counter clean and free of oil splats. For further convenience, the removable non-stick coated drawer and the food basket can be cleaned in the dishwasher. Preventing the smell of oil and fried items taking over your house is the rapid air technology of this air fryer. \r\n\r\nUnique design for delicious and low-fat cooking results\r\nThe Philips Air fryer has been designed for those people who want to keep their calories low and at the same time enjoy eating good food. With a distinct design, the appliance cooks your food perfectly at an optimum speed. A spread of dishes can be fried and cooked in this air fryer with the minimal use of oil.\r\n', 'fryer', 'philips,air fryer,fryer', NULL, '0', 'Y'),
(59, 'KITCHEN', '5', 'Thu Mar 20 08:39:18 PDT 2014', 'Philips Citrus Press HR2771 Juicer', '606', 'KEY FEATURES OF PHILIPS CITRUS PRESS HR2771 JUICER\r\n?	Juice Extractor\r\n?	25 W Power Consumption\r\n?	Juicing Feature\r\n?	0.5 L Extractor Jar\r\n', 'juicer', 'philips,juicer', NULL, '0', 'Y'),
(60, 'KITCHEN', '6', 'Thu Mar 20 09:05:37 PDT 2014', 'BLACK & DECKER PRSM600 FOOD PROCESSOR', '41995', 'KEY FEATURES OF BLACK & DECKER PRSM600 FOOD PROCESSOR\r\n?	Anti-splash Shield\r\n?	2 Bowls with 3 L and 4.5 L Capacity\r\n?	Kebab Attachment\r\n?	2 Mixing Bowls\r\n?	800 W Power Consumption\r\n?	Safety Lock-on System\r\n', 'food processor', 'processor,decker', NULL, '0', 'Y'),
(61, 'TOYS & GAMES', '1', 'Thu Mar 20 09:25:16 PDT 2014', 'Maisto Off-road Dune Blaster ', '2995', 'Key Features of Maisto Off-road Dune Blaster (Orange) \r\n?	Steering Alignment Adjustment\r\n?	Full Function Radio Control\r\n?	Big Off Road Tires\r\n?	1:16 Scale\r\n', 'blaster', 'maisto road blaster', NULL, '0', 'Y'),
(62, 'BOOK', '1', 'Thu Mar 20 22:05:58 PDT 2014', 'COMPILERS PRINCIPLES, TECHNIQUES, AND TOOLS, 2ED 2nd Edition (Paperback)', '579', 'Ravi Sethi, D. Jeffrey Ullman, Alfred V. Aho and Monica S. Lam?s COMPILERS PRINCIPLES, TECHNIQUES, AND TOOLS, 2ED 2 Edition is for 5th Semester, 7th Semester, 6th Semester computer science engineering students. The books comes with a complete front end and finding linearly independent solutions so as to have a better understanding of the subject. The books covers syllabus for information technology and computer science engineering.\r\nAbout the authors\r\nRavi Sethi is an Indian computer scientist and the president of Avaya Labs. He has co-authored books like the Compilers: Principles, Techniques, and Tools (2nd Edition) 0002 Edition, PROGRAMMING LANGUAGES : CONCEPTS & CONSTRUCTS 2ED 2 Edition and penned down Programming Language with Java Package (2nd Edition). Sethi studied in IITK and attended Princeton University for his Ph.D.\r\nD. Jeffrey Ullman is a computer scientist and professor at the Stanford University. He has co-authored books like Database Systems: The Complete Book (with H. Garcia-Molina and J. Widom), Prentice-Hall, Englewood Cliffs, Elements of ML Programming, Prentice-Hall, Englewood Cliffs and Fundamental Concepts of Programming Systems, Addison-Wesley, Reading MA. He attended Columbia University for his degree and received his Ph.D from the Princeton University.\r\nAlfred V. Aho is a Canadian computer scientist. He has co-authored books like the The Theory of Parsing, Translation, and Compiling, Vol. 1 and The Design and Analysis of Computer Algorithms. Aho attended University of Toronto and went on to do his Ph.D from the Princeton University.\r\nMonica S. Lam is a computer science professor at the Stanford University. She has authored A Systolic Array Optimizing Compiler. Lam attended University of British Colombia for her bachelors and the Carnegie Mellon University to receive her Ph.D\r\n', 'technical book', 'book,compiler ,technical book', '4', '0', 'Y'),
(63, 'BOOK', '2', 'Thu Mar 20 22:15:04 PDT 2014', 'Ramayan 3392 AD (Volume - 2) ', '223', 'Valmikis Ramayan takes a new spin as Shamik Dasguptas virbant illustrations continue the story of Ram and Lakshman, exiled from post-apocalyptic Ayodhya, as they try to protect Princess Seeta.\r\nSummary of the Book\r\nRam and Lakshman continue in their adventures, reaching Mithila where they find King Janaka and the Princess Seeta. Seetas powers are drawn from the Earth itself, and Janaka claims that she is the daughter of the Earth. The sage Vishwamitra reveals that Ram must now protect Seeta to save the world. Ram understands his Dharma but he finds Seeta very difficult to be around.\r\nAbout Shamik Dasgupta\r\nShamik Dasgupta is an Indian comic book writer. He is well known for his Ramayan 3392 A.D. series and The Caravan.\r\n\r\n', 'book', 'ramayan,book', NULL, '0', 'Y'),
(64, 'BOOK', '3', 'Thu Mar 20 22:18:26 PDT 2014', 'Asterix The Gaul 1 ', '274', 'The first ever volume of the famed Asterix comic book series, it is certainly the nostalgic starting point for all Asterix fans.\r\nSummary Of The Book\r\nThe story begins, as all of Asterix?s adventures do, by invoking the state of Gaul at the time ? occupied by the Romans, though not entirely. The one small village of indomitable Gauls still holding out against the invaders is slowly zoomed into. In this first ever adventure, the Romans, led by Centurion Crismus Bonus attempt to figure out what gave the Gauls their superhuman strength. They find that the secret lies in a potion brewed by their fearsome (yet rather fatherly) druid, Getafix. This leads them to their first ever attempt to capture the venerable druid, which they manage to do without a snag, at least initially.\r\nThe druid is captured and tortured until the torturer is utterly exhausted and stunned by the resistance of Getafix to his methods. Instead, they capture Asterix, who had caught wind of the Romans? scheme and snuck into their camp, and try to torture him instead, which works brilliantly ? so brilliantly that the torturer hardly had to tie him down before the Gaulish warrior began to beg for mercy. This forces Getafix to comply with the Romans? demand to brew his secret potion for them and goes on to give them an elaborate list of ingredients. But what exactly will the druid concoct? Will it be his famous magic potion or do Asterix and Getafix have other tricks up their sleeves?\r\nAsterix The Gaul was named the twenty third most influential book of the twentieth century by the magazine Le Monde. It was first serialized in the French comic magazine Pilote before it was compiled into the well known first volume. Despite many inconsistencies in drawing and characterizations, this book is a fitting start to the beloved Asterix series.\r\nAbout The Authors\r\nAlbert Uderzo is a French script writer and comic book artist. He is best known for his work on the Asterix series along with Rene Goscinny, which so far comprises of thirty four volumes. He is also known for Flamberge, Belloy, Tanguy et Laverdure, and Oumpah-pah.\r\nUderzo is the third most translated French comic book author according to UNESCO?s Index Translationum. He has been highly honored over the years, having received the Knight of the Legion of Honour in 1985, been inducted into the Eisner Award Hall of Fame in 2005 and been made a Knight of the Order of the Netherlands Lion. He is married to Ada Uderzo and has a daughter Sylvie Uderzo.\r\nRene Goscinny was a French comic book editor and writer. He is best known for his work on the Asterix series along with Albert Uderzo, though he has also worked on many other projects such as Iznogoud, Le Petit Nicolas, Lucky Luke and Oumpah-pah. UNESCO?s Index Translationum named Goscinny the twenty second most translated author in the world. He has received several awards ? Adamson Award for best comic strip artist in 1974, and was inducted in the Will Eisner Hall of Fame as a Judges choice in 2005. He married Gilberte Pollaro-Millo and had a daughter Anne Goscinny.\r\n', 'comic', 'Asterix,book', NULL, '0', 'Y'),
(65, 'BOOK', '4', 'Thu Mar 20 22:22:44 PDT 2014', 'Kapilavastu (Volume - 1)', '231', 'The story is a retelling of the life of the young prince, as he runs away from the luxuries of the castle and shuns Hindu practices such as ascetic self-mutilation and caste system. The story takes a different take on the path that leads Gautama to his enlightenment as opposed to resignation and impassivity, Buddha as portrayed by the author uses wit and humor to look at the situations around him and leads the understanding of how ordering ones life sensibly can solve a number of problems faced in life. The first volume of Buddha: Kapilavastu (Volume - 1) deals with three different characters. Chapra is an ambitious slave who decides to give his caste system a miss and rise above it. The second is Tatta, a wild pariah child who can communicate with animals. Then there is the monk, Naradatta, who attempts to read and understand the various signs that surround the birth of prince Siddhartha.\r\nOsamu Tezuka was a Japanese manga artist and cartoonist, who is often considered to be the Japanese equivalent of Walt Disney owing to his contribution in the field of Japanese Anime. Some of his well known works are Metropolis, Jungle Taitei (Jungle Emperor), and Tetsuwan ATOM (Astro Boy)\r\n', 'novel', 'kapilavastu,book,novel', '2', '0', 'Y'),
(66, 'BOOK', '5', 'Thu Mar 20 22:30:00 PDT 2014', 'THE INVISIBLE MAN ', '176', 'The stranger came early in February, one wintry day, through a biting wind and a driving snow. When the residents of Iping first see him, he is wearing an overcoat and goggles, and is covered from head to toe with bandages. His hidden identity and mysterious behaviour causes the locals to start asking questions. At fi rst they assume he must have been involved in some kind of horrific accident. But the truth is far more alarming than that. As the reality of the situation starts to become clear, only one thing is certain; the stranger is a troubled soul and can only deal with his personal fear by terrorising the people around him. First published in 1897, The Invisible Man is HG Wells?s warning to the world about the dangers of science without humanity.\r\n', 'story book', 'story book,invisible man', NULL, '0', 'Y'),
(67, 'BOOK', '6', 'Thu Mar 20 22:33:57 PDT 2014', 'Devi (Volume - 2) ', '224', 'Between the divine and the diabolical, there is . . . The power of the Goddess is unrivalled. Forged by the strength of the Gods, Devi retains a force meant to bring balance among Gods and men. But the current Devi incarnate s different. Her female host, Tara Mehta, is still alive and struggles to comprehend the awesome responsibility she now faces. Humanity is threatened by the fallen Lord Bala and salvation rests in the hands of a Goddess-torn in two. Devi wields the power of the Gods, as well as the virtue that makes the female entity so distinct, yet so vulnerable: compassion. The Divine and the Diabolical collide in an epic battle, culminating in a night of reckoning in Devi: Samarva, the exciting sequel to the premier volume! ', 'god book', 'devi,god book', NULL, '0', 'Y'),
(68, 'BOOK', '7', 'Thu Mar 20 22:39:34 PDT 2014', 'Superman: Red Son ', '822', 'Hes a strange visitor from another world who can change the course of mighty rivers, bend steel in his bare hands????and who, as the champion of the common worker, fights a never-ending battle for Stalin, Socialism and the international expansion of the Warsaw Pact.\r\n\r\nA deftly written alternate take on the mythos of the Man of Steel, RED SON explores the classic tale of Supermans origins????if his rocketship had landed in the Soviet Union rather than Smallville, Kansas\r\n', 'comic', 'superman', '2', '0', 'Y'),
(69, 'BOOK', '8', 'Thu Mar 20 22:43:33 PDT 2014', '300 (Hardcover) ', '1853', 'The armies of Persia--a vast horde greater than any the world has ever known--are poised to crush Greece, an island of reason and freedom in a sea of madness and tyranny. Standing between Greece and this tidal wave of destruction are a tiny detachment of but three hundred warriors. Frank Miller`s epic retelling of history`s supreme moment of battlefield valor is finally collected in a glorious hardcover volume in its intended format-- each two-page spread from the original comics is presented as a single undivided page', 'comic', 'handcover,300', '3', '0', 'Y'),
(70, 'BOOK', '9', 'Thu Mar 20 22:48:45 PDT 2014', 'Art and Craft ', '120', 'Art is to be nurtured for sheer joy! Every article in this book will bring joy to one who makes it, as well as to the viewer.\r\n\r\nAbout the Author\r\nShe has an experience of over 12 years of working in schools as a art & craft teacher. She also used to conduct art & craft programmes, workshops and classes for children\r\n', 'art and craft', 'art,craft', NULL, '0', 'Y'),
(71, 'BOOK', '10', 'Thu Mar 20 22:50:23 PDT 2014', 'MY EVEN MORE WONDERFUL WORLD OF FASHION ', '1358', 'A wonderful celebration of dressing up, this follow-up to the hugely successful My Wonderful World of Fashion will appeal to fashion addicts from 8 years up. With hundreds more drawings to complete and colour in, garments to design and textile patterns to invent, it takes your imagination even further into the creation of exciting new styles', 'art and craft', 'drawing,art', '2', '0', 'Y'),
(72, 'BOOK', '11', 'Thu Mar 20 22:57:03 PDT 2014', '365 Things To Make And Do ', '374', 'Rainy days will never be dull and boring again! There are so many creative and fun things for children to make and do, all here in the 365 Things to Make and Do book. By recycling items and objects from around the home, and following simple step-by-step instructions, a huge variety of projects can easily be made.\r\nThe areas covered in 365 Things to Make and Do are:\r\nIn the Kitchen \r\nNature \r\nCards and Wrappings \r\nIndoor Crafts \r\nToys and Games \r\nAt the Seaside \r\nModels and Boxes \r\nSpecial Occasions\r\n', 'art and craft', 'art,things to do', '2', '0', 'Y'),
(73, 'BOOK', '16', 'Thu Mar 20 22:59:40 PDT 2014', 'Eco-friendly Crafting with Kids: 35 Step-by-step Projects for Preschool Kids and Adults to Create Together (Hardcover) ', '1297', 'Small children love crafting and creating, and its educational as well as enjoyable - crafting can help develop fine motor skills and teaches small children to follow instructions and work alongside someone else. Kate Lilleys hugely popular blog, Minieco, grew out of her desire to teach her own kids to be resourceful and use whats around them for creative play. Parents and kids alike will love the 35 bold, colourful projects featured in the book and divided into sections that include Music, Nature, Sewing, Science and Recycling Bin. The final section contains a list of 50 quick boredom busters that harassed parents can pull out of the bag in an emergency! ', 'art and craft', 'craft,handcover', '2', '0', 'Y'),
(74, 'TOYS & GAMES', '2', 'Thu Mar 20 23:06:51 PDT 2014', 'Maisto Red Bull F1 2013 ', '1560', 'Inclusive of taxes \r\n?	Cars & Bikes\r\n?	Scale 01:18	?	Manufactured in China\r\n?	8 Years +\r\n\r\n                                        General\r\nType	Cars & Bikes\r\n\r\nIdeal For	Boys\r\nAge Group	8 Years +\r\nAssembly Required	No\r\nScale	01:18\r\nMaterial	ABS Plastic\r\nCountry of Manufacture	China\r\nControl Features\r\nRemote Control Features	Turn Left, Forward, Turn Right, Backward\r\nOther Control Features	Full Function\r\nAdditional Features\r\nOther Features	11 inch Long Car (Approx.)\r\nControl Features\r\nRemote Control Features	Turn Left, Forward, Turn Right, Backward\r\nOther Control Features	Full Function\r\n', 'car', 'maisto car', NULL, '0', 'Y'),
(75, 'TOYS & GAMES', '3', 'Thu Mar 20 23:19:09 PDT 2014', 'Meccano Design 1 New Generation ', '1499', 'Key Features \r\n?	Improve Creative Skillss & Hand-Eye Coordination\r\nHave more fun on wheels with your little biker at home with Meccano Design 1 New Generation. The Meccano Design 1 New Generation will provide hours of building fun for your child and will enhance his assembly skills. This bike construction kit will invariably become your child?s favourite play set as he can construct 3 different models with an assortment of 153 different parts. The model will appeal to your kid even more because of the brilliant ultra-modern shiny parts that renders a modern race look. The steel body parts are flexible for more realistic model building and they return to their original shape after use. The Meccano Design 1 New Generation suitable for boys aged 8 years and above will make a very good birthday gift for the young designers.\r\n', 'board game', 'meccano game', '3', '0', 'Y'),
(76, 'TOYS & GAMES', '4', 'Thu Mar 20 23:21:26 PDT 2014', 'Meccano Police Bucket ', '1299', 'Key Features \r\n?	Facilitates in Building their Confidence\r\n?	Child Learn about Keeping the Streets Safe\r\nChildren love their toys and your little ones are sure to be enthralled by this one.The Meccano Police Bucket not only lets him play with it, but facilitates in building their confidence, that too from scratch. This versatile toy comes with the necessary tools using which your kids can learn important life lessons. What?s more, thanks to role-playing you can also be a part of it, endless hours of action-packed playtime assured. Watch your child learn about keeping the streets safe while they have fun. This Meccano toy is suitable for boys and girls above the age of 4. Bring home the Meccano Police Bucket and help your kids get a fresher view of the world.\r\n', 'game', 'police bucket ,game', NULL, '0', 'Y'),
(77, 'TOYS & GAMES', '5', 'Thu Mar 20 23:24:33 PDT 2014', 'Meccano Spitfire ', '3199', 'Key Features \r\n?	319 Peices\r\n?	Tools Included\r\n?	Build The Classic Spitfire\r\n?	Ideal for Collectors\r\nSpitfire was one of the most famous aircraft that was used by British in World War II. Let your little child also win his battle with the help of this amazing Spitfire aircraft that is exclusively designed by Meccano.\r\n319 Pieces\r\nThe Meccano Spitfire comes in a pack of 319 pieces which have to be assembled to build up this special edition aircraft for that important battle.\r\nBuild The Classic Spitfire\r\nYour little child has to collect and assemble all the parts to build this classic Spitfire.\r\nIdeal For Collectors\r\nIf your little collector is one who has a keen interest in building and mechanics, then this aircraft toy is an ideal choice.\r\nTools Included\r\nIn addition, there are small tools which can be used by your kid to assemble and fix the pieces in their right place.\r\n', 'game', 'game', '3', '0', 'Y'),
(78, 'TOYS & GAMES', '5', 'Thu Mar 20 23:24:33 PDT 2014', 'Meccano Spitfire ', '3199', 'Key Features \r\n?	319 Peices\r\n?	Tools Included\r\n?	Build The Classic Spitfire\r\n?	Ideal for Collectors\r\nSpitfire was one of the most famous aircraft that was used by British in World War II. Let your little child also win his battle with the help of this amazing Spitfire aircraft that is exclusively designed by Meccano.\r\n319 Pieces\r\nThe Meccano Spitfire comes in a pack of 319 pieces which have to be assembled to build up this special edition aircraft for that important battle.\r\nBuild The Classic Spitfire\r\nYour little child has to collect and assemble all the parts to build this classic Spitfire.\r\nIdeal For Collectors\r\nIf your little collector is one who has a keen interest in building and mechanics, then this aircraft toy is an ideal choice.\r\nTools Included\r\nIn addition, there are small tools which can be used by your kid to assemble and fix the pieces in their right place.\r\n', 'game', 'game', NULL, '0', 'Y'),
(79, 'BOOK', '3', 'Thu Mar 27 08:36:32 IST 2014', 'mama', '123', '123132', 'malas', '123', '2', '123', 'Y'),
(81, 'BOOK', '16', 'Fri Mar 28 03:54:26 IST 2014', '132', '150', 'sasa', '123', '150', '3', '150', 'Y'),
(82, 'ELECTRONICS', '15', 'Fri Mar 28 04:03:43 IST 2014', '45454', '1500', '', '45454', '150', '2', '150', 'Y'),
(84, 'BOOK', '1', '150', '123', '150', '150', '123', '150', NULL, '150', 'Y'),
(85, 'BOOK', '3', 'Sun Mar 30 04:40:10 IST 2014', '123', '123', '12312321321', '123', '123', NULL, '4', 'Y'),
(86, 'BOOK', '3', 'Sun Mar 30 04:43:37 IST 2014', '987', '555', '5555', '655', '555', '2', '1', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchase`
--

CREATE TABLE IF NOT EXISTS `tbl_purchase` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardNumber` varchar(255) DEFAULT NULL,
  `amount` varchar(500) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `userId` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `isActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=112 ;

--
-- Dumping data for table `tbl_purchase`
--

INSERT INTO `tbl_purchase` (`id`, `cardNumber`, `amount`, `productId`, `userId`, `price`, `isActive`) VALUES
(105, '9876543210', 'null', '48', '17', '50490', 'N'),
(104, '123456789', 'null', '17', '17', '106', 'N'),
(103, '123', 'null', '68', '16', '822', 'N'),
(102, '123', 'null', '1', '16', '145', 'Y'),
(101, '123', 'null', '17', '16', '106', 'Y'),
(100, '123', 'null', '17', '16', '106', 'Y'),
(99, '123456131', 'null', '17', '16', '106', 'Y'),
(106, '1234567889', 'null', '17', '16', '106', 'Y'),
(107, '123456799123', 'null', '40', '20', '3000', 'Y'),
(108, '987654321000', 'null', '77', '21', '3199', 'Y'),
(109, '123456799123', 'null', '32', '20', '3500', 'Y'),
(110, '123456799123', 'null', '32', '20', '3500', 'Y'),
(111, '123456799123', 'null', '85', '20', '123', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_registration`
--

CREATE TABLE IF NOT EXISTS `tbl_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `edit` int(1) NOT NULL,
  `delete` int(1) NOT NULL,
  `add` int(1) NOT NULL,
  `txtFullName` varchar(20) DEFAULT NULL,
  `txtContactNo` varchar(20) DEFAULT NULL,
  `txtEMail` varchar(50) DEFAULT NULL,
  `txtUserName` varchar(50) DEFAULT NULL,
  `txtPassword` varchar(20) DEFAULT NULL,
  `txtType` varchar(3) NOT NULL,
  `cardNumber` varchar(12) NOT NULL,
  `cardPin` int(4) NOT NULL,
  `question` int(1) NOT NULL,
  `answer` varchar(10) NOT NULL,
  `otp` int(11) NOT NULL,
  `isRequest` varchar(1) NOT NULL,
  `isActive` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbl_registration`
--

INSERT INTO `tbl_registration` (`id`, `edit`, `delete`, `add`, `txtFullName`, `txtContactNo`, `txtEMail`, `txtUserName`, `txtPassword`, `txtType`, `cardNumber`, `cardPin`, `question`, `answer`, `otp`, `isRequest`, `isActive`) VALUES
(19, 0, 0, 0, 'admin', '7894561230', 'admin@gmail.com', 'admin@gmail.com', '123456', 'nul', '100212121212', 4444, 1, 'cricket', 0, '', 'Y'),
(20, 9, 0, 0, 'pravintumsare', '7894561230', 'pravintumsare@gmail.com', 'pravintumsare@gmail.com', '123', '3', '123456799123', 1212, 1, 'cricket', 7375, '', 'N'),
(21, 0, 0, 0, 'jerry', '9876543210', 'developer.pm.sagar@gmail.com', 'developer.pm.sagar@gmail.com', '123456', '3', '987654321000', 1111, 2, 'paris', 0, '', 'Y'),
(22, 0, 0, 0, 'sagar verma', '7889456123', 'eew.sagar@gmail.com', 'eew.sagar@gmail.com', '123456', '3', '987654321000', 1111, 2, 'cricket', 0, '', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_review`
--

CREATE TABLE IF NOT EXISTS `tbl_review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `byUser` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `entryDate` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `tbl_review`
--

INSERT INTO `tbl_review` (`id`, `byUser`, `productId`, `entryDate`) VALUES
(1, 0, 48, NULL),
(2, 0, 2, NULL),
(3, 0, 31, NULL),
(4, 12, 47, NULL),
(5, 12, 32, NULL),
(6, 12, 17, NULL),
(7, 12, 17, NULL),
(8, 12, 17, NULL),
(9, 12, 17, NULL),
(10, 12, 2, NULL),
(11, 12, 2, NULL),
(12, 12, 1, NULL),
(13, 12, 73, NULL),
(14, 12, 65, NULL),
(15, 12, 71, NULL),
(16, 12, 72, NULL),
(17, 12, 79, NULL),
(18, 12, 86, NULL),
(19, 12, 9, NULL),
(20, 12, 62, NULL),
(21, 12, 62, NULL),
(22, 0, 17, NULL),
(23, 16, 2, NULL),
(24, 16, 2, NULL),
(25, 0, 49, NULL),
(26, 16, 49, NULL),
(27, 0, 8, NULL),
(28, 16, 17, NULL),
(29, 16, 17, NULL),
(30, 16, 17, NULL),
(31, 0, 17, NULL),
(32, 0, 17, NULL),
(33, 16, 2, NULL),
(34, 16, 2, NULL),
(35, 16, 81, NULL),
(36, 16, 81, NULL),
(37, 16, 69, NULL),
(38, 16, 69, NULL),
(39, 16, 62, NULL),
(40, 16, 17, NULL),
(41, 16, 17, NULL),
(42, 16, 1, NULL),
(43, 16, 68, NULL),
(44, 0, 17, NULL),
(45, 0, 48, NULL),
(46, 17, 17, NULL),
(47, 0, 48, NULL),
(48, 17, 48, NULL),
(49, 0, 2, NULL),
(50, 16, 17, NULL),
(51, 0, 2, NULL),
(52, 20, 1, NULL),
(53, 20, 40, NULL),
(54, 20, 41, NULL),
(55, 21, 62, NULL),
(56, 21, 77, NULL),
(57, 20, 32, NULL),
(58, 0, 32, NULL),
(59, 20, 85, NULL),
(60, 20, 69, NULL),
(61, 0, 20, NULL);
