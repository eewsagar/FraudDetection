/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.mailService;

/**
 *
 * @author PraviN
 */
public class SendMail {

    public static void sendRegistrationMail(String userName, String cardNumber, String cardPassword) {
        try {
            Sendemail.sucessRegistration(userName, ""
                    + "YOUR LOGIN DETAILS : - \n"
                    + "Card number :-  "
                    + "" + cardNumber + "\n"
                    + "Card Pin  :- "
                    + "" + cardPassword + "\n"
                    + ""
                    + "");
        } catch (Exception e) {
            System.out.println("error :"+e);
            
        }
        
      
    }
    public static void main(String[] args) {
        SendMail sendMail = new SendMail();
        sendMail.sendRegistrationMail("eew.sagar@gmail.com", "123456789000", "12345");
    }

}
