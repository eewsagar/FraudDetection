/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.cardUtil;

import java.util.Random;

/**
 *
 * @author PraviN
 */
public class CardUtil {

    public static void main(String[] args) {
        CardUtil cardUtil = new CardUtil();
        String generateCardNumber = cardUtil.generateCardNumber();
        System.out.println("generateCardNumber = " + generateCardNumber);
        String generateCardPin = cardUtil.generateCardPin();
        System.out.println("generateCardPin = " + generateCardPin);
    }

    public String generateCardNumber() {
        return createRandomInteger(0, 121212, new Random(123456789));
    }

    public String generateCardPin() {
        String cardPinRaw = "" + System.currentTimeMillis();
        String substring = cardPinRaw.substring(cardPinRaw.length() - 4, cardPinRaw.length());
        return substring;
    }

    private String createRandomInteger(int aStart, long aEnd, Random aRandom) {
        long range = aEnd - (long) aStart + 1;
        long fraction = (long) (range * aRandom.nextDouble());
        long randomNumber = fraction + (long) aStart;
        return String.valueOf(randomNumber + System.currentTimeMillis());
    }

}
