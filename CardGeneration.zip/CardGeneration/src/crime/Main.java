/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crime;

import javax.swing.JDialog;
import javax.swing.JFrame;

/**
 *
 * @author seabirds
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                try {
                    SplashScreen splashScreen = new SplashScreen(null, true);
                    splashScreen.setVisible(true);
                    JFrame.setDefaultLookAndFeelDecorated(true);
                    JDialog.setDefaultLookAndFeelDecorated(true);
                    MainFrame mf=new MainFrame();
                    mf.setVisible(true);
                    mf.setTitle("Resilient Identity Crime Detection ");
                } catch (Exception e) {
                    System.out.println("e = " + e);
                }
            }
        });
    }
}
